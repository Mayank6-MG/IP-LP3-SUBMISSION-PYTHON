a=int(input("Enter the first no."))
b=int(input("Enter the second no."))
c=a+b
print(c)
if(a<b):
    print("Negative answer because ",a, "is less than",b,)
    d1=a-b
    print(d1)
else:
    d1=a-b
    print(d1)
e=a*b
print(e)
