import datetime
print(datetime.date(2015,6,16).isocalendar()[1])
